export const dataConfig = {
  API_URL: "http://10.42.0.216:8080/api",
}